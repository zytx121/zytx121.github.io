from pathlib import Path
import csv,math
base=Path(__file__).resolve().parent
rows=list(csv.DictReader((base/'stereo.csv').open(encoding='utf-8-sig')))
errors=[]
for r in rows:
    d=float(r['x_left_px'])-float(r['x_right_px'])
    z=800.0*1.0/d
    delta=z-float(r['Z_m']);errors.append(delta)
    print('point',r['id'],'depth_m',round(z,6),'error_m',round(delta,8),'perturbed_depth_m',round(800.0/(d+0.5),5))
print('RMSE on ideal synthetic observations:',math.sqrt(sum(e*e for e in errors)/len(errors)))
assert max(abs(e) for e in errors)<1e-5
print('Synthetic geometry check passed. This is not real-device accuracy.')
